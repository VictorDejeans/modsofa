# modSofa - Minecraft Bedrock Addon

Sofas modulaires avec connexions automatiques.

## Structure
- behavior_packs/ : Logique et scripts
- resource_packs/ : Modèles et textures